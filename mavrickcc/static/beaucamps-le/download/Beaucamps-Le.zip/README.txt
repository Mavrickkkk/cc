================================================================
BEAUCAMPS-LE — Free Typeface
================================================================

Designed by Mavrick
Version 1.0 — 2026


----------------------------------------------------------------
ABOUT
----------------------------------------------------------------

Beaucamps-Le is a free typeface designed with Fontforge.


----------------------------------------------------------------
FILES INCLUDED
----------------------------------------------------------------

Beaucamps-Le.ttf / BeaucampsLe.otf    → Install on Mac / Windows / Linux
Beaucamps-Le.woff2  → Web use (modern browsers)
Beaucamps-Le.woff   → Web use (older browsers)


----------------------------------------------------------------
INSTALLATION
----------------------------------------------------------------

Mac
  Double-click the .ttf file → click "Install Font"

Windows
  Right-click the .ttf file → select "Install"

Linux
  Copy the .ttf file to ~/.fonts/ or /usr/share/fonts/


----------------------------------------------------------------
WEB USE
----------------------------------------------------------------

@font-face {
  font-family: 'Beaucamps-Le';
  src: url('Beaucamps-Le.woff2') format('woff2'),
       url('Beaucamps-Le.woff')  format('woff');
  font-weight: normal;
  font-style: normal;
}


----------------------------------------------------------------
LICENSE
----------------------------------------------------------------

This font is released under the SIL Open Font License 1.1.
You are free to use, share, and modify it.
Full license text in LICENSE.txt


----------------------------------------------------------------
CONTACT
----------------------------------------------------------------

mavrick.cc

================================================================